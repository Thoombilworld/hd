<?php
$HS_APP_NAME = '{{APP_NAME}}';
$HS_BASE_URL = '{{BASE_URL}}';
$HS_DB_HOST = '{{DB_HOST}}';
$HS_DB_NAME = '{{DB_NAME}}';
$HS_DB_USER = '{{DB_USER}}';
$HS_DB_PASS = '{{DB_PASS}}';
